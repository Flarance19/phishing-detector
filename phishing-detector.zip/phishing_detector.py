#!/usr/bin/env python3
"""
PhishGuard - Machine Learning Phishing Email Detector
======================================================
Uses Scikit-learn with TF-IDF + engineered features to classify
emails as Phishing or Safe with high accuracy.

Usage:
    python phishing_detector.py              # train and evaluate
    python phishing_detector.py --predict    # interactive prediction mode
"""

import sys, re, json, warnings, urllib.parse
import numpy as np
import pandas as pd
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import (accuracy_score, confusion_matrix,
                              classification_report, roc_auc_score)
from sklearn.preprocessing import MinMaxScaler
from scipy.sparse import hstack, csr_matrix

# ─────────────────────────────────────────────────────────────────────────────
# DATASET
# ─────────────────────────────────────────────────────────────────────────────

PHISHING_EMAILS = [
    "URGENT: Your account has been suspended! Verify NOW: http://paypa1-secure.xyz/login?token=abc123 or lose access permanently!",
    "Congratulations! You've won $1,000,000 lottery! Claim at http://mega-win-prize.ru/get?id=VIP Limited offer!",
    "Dear customer, unusual activity on your bank account. Login: http://bankofamerica-secure.tk/verify immediately!",
    "Your Apple ID locked. Unlock: http://apple-id-verification.cc/restore or access permanently disabled.",
    "ALERT: PayPal account limited. Resolve: http://paypal-resolution-center.xyz/case?ref=PP2024 immediately!",
    "Pending package delivery. Confirm address: http://fedex-delivery-rescheduling.com/track?id=7723 urgently!",
    "Security breach! Password exposed. Reset NOW: http://secure-password-reset-now.info/reset?user=victim",
    "Netflix: Payment failed. Update billing: http://netflix-billing-update.cc/payment or subscription cancelled.",
    "IRS: Tax refund $3,200 owed. Claim: http://irs-refund-2024.xyz/claim?ssn=required before deadline!",
    "WINNER: Amazon gift card $500! Claim: http://amazon-giftcard-free.ru/claim?winner=you TODAY ONLY!",
    "Microsoft account requires verification. Click: http://microsoft-account-verify.tk/login?urgent=true",
    "Bank Alert: Suspicious login detected. Secure now: http://chase-secure-center.xyz/protect?case=9291",
    "FREE iPhone 15 winner! Claim: http://free-iphone15-winner.cc/claim?code=WIN2024 expires in 1 hour!",
    "FINAL NOTICE: Domain expiring! Renew: http://domain-renewal-urgent.info/renew?discount=80off NOW!",
    "Dropbox: Storage full, files deleted in 24h! Upgrade: http://dropbox-upgrade-now.xyz/plan?save=files",
    "SSN compromised! Act NOW: http://ssa-identity-protection.tk/secure?case=breach2024 urgent action!",
    "Crypto wallet: Confirm transaction or lose 2.5 BTC: http://blockchain-confirm-tx.ru/verify?wallet=yours",
    "AMAZON: Unusual purchase $847 detected. Cancel: http://amazon-order-cancel.tk/dispute?order=FK293",
    "VERIFY Gmail now or deleted: http://gmail-verification-required.cc/verify?account=yours&deadline=24h",
    "Loan pre-approved $50,000! Claim: http://fast-loan-approved-2024.xyz/claim?preapproved=true&code=VIP",
    "WhatsApp expiring! Renew: http://whatsapp-renewal-2024.xyz/pay?amount=0.99 urgent!",
    "HR: Employment records need update. Submit: http://hr-employee-portal-update.xyz/form?employee=you",
    "Password expiring in 24 hours! Reset: http://corporate-password-reset.xyz/update?force=true NOW!",
    "Unclaimed rewards $750 expiring! Redeem: http://rewards-unclaimed-2024.ru/redeem?id=customer today!",
    "Spotify: Verify payment: http://spotify-payment-verify.tk/billing?account=suspend risk!",
    "GOVERNMENT GRANT: Qualify $12,500! Apply: http://government-grant-apply.xyz/eligible?ssn=needed",
    "Email storage 99% full! Upgrade NOW: http://email-storage-upgrade.cc/plan?promo=freespace expires!",
    "LinkedIn: 500 profile views! See who FREE: http://linkedin-profile-viewers.cc/see?premium",
    "Insurance lapse warning! Pay $49: http://insurance-renewal-urgent.info/pay?policy=lapse NOW!",
    "EBAY seller suspended. Appeal: http://ebay-seller-appeal.cc/reinstate?seller=yours urgent!",
    "Card charged $299 unauthorized! Dispute: http://card-dispute-center.tk/cancel?charge=unauthorized",
    "FINAL WARNING: Legal action 48 hours! Pay: http://legal-settlement.xyz/pay?case=court24 now!",
    "Zoom deactivated. Reactivate: http://zoom-account-restore.cc/verify?meeting=resume today!",
    "Google Account suspended! Recover: http://google-account-recovery.xyz/restore?gmail=yours urgent!",
    "Your credit score dropped 100 points! Check: http://credit-alert-now.xyz/score?fix=urgent&id=you",
]

SAFE_EMAILS = [
    "Hi Sarah, attached is the Q3 financial report. Let me know if you need clarifications. Best, John",
    "Team meeting tomorrow 2PM in conference room B. Agenda: project updates and sprint planning.",
    "Your Amazon order #112-3456789 shipped! Expected delivery Thursday. Track at amazon.com/orders",
    "Thanks for subscribing to our newsletter. You can unsubscribe anytime from our website footer.",
    "Following up on our conversation last week regarding the new marketing project proposal.",
    "Your monthly bank statement is ready. Log in at bankofamerica.com to view it securely.",
    "Reminder: Dentist appointment March 15th at 10:00 AM. Please call to reschedule if needed.",
    "The Q4 roadmap document has been shared with you on Google Drive. Click the link to view.",
    "Happy Birthday! Wishing you a wonderful day filled with joy, laughter, and happiness.",
    "Flight confirmation: AA1234 on Dec 20. Check-in opens 24 hours before departure at aa.com",
    "Best Buy receipt for order #4892763 is attached. Thank you for your purchase today!",
    "Good morning team! Today's standup: 1) Blockers 2) Progress updates 3) Plan for day.",
    "Invoice #2024-089 for services rendered in October attached. Payment due in 30 days.",
    "Weekly analytics report ready. Visit dashboard.company.com for your performance stats.",
    "Reaching out about the Senior Developer position posted on LinkedIn last week.",
    "Package delivered to front porch. Driver left delivery notification at your door.",
    "Conference call confirmed for Friday at 3PM EST. Dial-in details in your calendar.",
    "Congratulations on completing the Advanced Python course! Certificate ready to download.",
    "GitHub pull request #342 reviewed and approved by 2 team members. Ready to merge.",
    "Reminder: Submit timesheet by EOD Friday. Access HR portal at hr.company.com/timesheet",
    "Book club meeting Saturday 7PM. We're discussing chapters 10-15. Bring your notes!",
    "Support ticket #9928 has been resolved. Please rate your experience with our team.",
    "New comment on your blog: Great article! Very informative and well-written content.",
    "Zoom subscription renews January 1st. Manage billing at zoom.us/billing anytime.",
    "Quarterly performance review scheduled next Monday. Prepare self-assessment form.",
    "Password changed successfully. Contact support if you did not make this change.",
    "SQL workshop starts in 3 days. Location: Building C Room 201. Bring your laptop.",
    "Design team completed mockups for the dashboard. Review them on Figma at your convenience.",
    "Tax documents for 2023 ready for download. Access them at irs.gov/account securely.",
    "Welcome to the team! Here is your onboarding checklist and credentials for week one.",
    "Weekly sync notes attached. Key decisions: launch delayed to Q2, budget approved.",
    "Adobe Creative Cloud renews Dec 31. No action needed unless you're changing plan.",
    "Feedback from your manager: excellent work on the API integration. Keep it up!",
    "Code review requested: PR #187 needs your input on database migration logic by Thursday.",
    "Office closed December 25-26 for the holidays. Emergency contact info on the wiki.",
]

# ─────────────────────────────────────────────────────────────────────────────
# FEATURE EXTRACTION
# ─────────────────────────────────────────────────────────────────────────────

URGENCY_WORDS = [
    'urgent','immediately','suspended','verify','winner','congratulations',
    'limited time','act now','alert','unusual activity','account locked','final notice',
    'expire','claim','free prize','selected','approved','breach','compromised',
    'lose access','terminated','legal action','warning','deadline','penalty',
    'resolve','confirm your','update billing', 'click here', 'click now'
]
BAD_TLDS = ['.xyz','.tk','.cc','.ru','.info','.top','.pw','.ml','.ga',
            '.cf','.gq','.loan','.click','.download','.win','.bid']

def extract_url_features(text):
    urls = re.findall(r'https?://\S+', text)
    if not urls:
        return dict(has_url=0, url_count=0, bad_tld=0, ip_url=0, url_len=0,
                    subdomains=0, has_at=0, has_query=0, lookalike=0)
    u = urls[0]
    try:
        domain = urllib.parse.urlparse(u).netloc
    except Exception:
        domain = ''
    lookalike = int(bool(re.search(
        r'(paypa1|g00gle|amaz0n|micros0ft|netfl1x|app1e|ebay-)', u, re.I)))
    return dict(
        has_url=1, url_count=len(urls),
        bad_tld=int(any(t in u.lower() for t in BAD_TLDS)),
        ip_url=int(bool(re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', domain))),
        url_len=len(u), subdomains=domain.count('.'),
        has_at=int('@' in u), has_query=int('?' in u), lookalike=lookalike
    )

def extract_text_features(text):
    low = text.lower()
    words = low.split()
    return dict(
        length=len(text), word_count=len(words),
        exclamations=text.count('!'), questions=text.count('?'),
        upper_ratio=sum(c.isupper() for c in text) / max(len(text), 1),
        urgency_score=sum(1 for w in URGENCY_WORDS if w in low),
        has_money=int(bool(re.search(r'[\$\€\£]|\d{1,3},\d{3}', text))),
        has_pct=int('%' in text),
        avg_word_len=np.mean([len(w) for w in words]) if words else 0,
        digit_ratio=sum(c.isdigit() for c in text) / max(len(text), 1),
    )

# ─────────────────────────────────────────────────────────────────────────────
# TRAIN
# ─────────────────────────────────────────────────────────────────────────────

def train():
    emails = PHISHING_EMAILS + SAFE_EMAILS
    labels = [1]*len(PHISHING_EMAILS) + [0]*len(SAFE_EMAILS)
    df = pd.DataFrame({'text': emails, 'label': labels})

    # Manual features
    Xm = pd.DataFrame([{**extract_url_features(t), **extract_text_features(t)}
                        for t in df['text']])
    scaler = MinMaxScaler()
    Xm_s = scaler.fit_transform(Xm)

    # TF-IDF
    tfidf = TfidfVectorizer(max_features=800, ngram_range=(1,2),
                             stop_words='english', sublinear_tf=True, min_df=1)
    Xtf = tfidf.fit_transform(df['text'])

    X = hstack([Xtf, csr_matrix(Xm_s)])
    y = df['label'].values
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y)

    models = {
        'Random Forest':       RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1),
        'Gradient Boosting':   GradientBoostingClassifier(n_estimators=200, random_state=42),
        'Logistic Regression': LogisticRegression(C=2.0, max_iter=1000, random_state=42),
    }

    SEP = "═" * 60
    print(f"\n{SEP}")
    print("  🛡  PhishGuard — Phishing Email Detection Model")
    print(SEP)
    print(f"  Dataset  : {len(emails)} emails ({len(PHISHING_EMAILS)} phishing, {len(SAFE_EMAILS)} safe)")
    print(f"  Train    : {X_tr.shape[0]} samples  |  Test: {X_te.shape[0]} samples")
    print(f"  Features : {X.shape[1]} (TF-IDF + 19 engineered)\n")

    best_acc, best_name, best_clf = 0, None, None

    for name, clf in models.items():
        clf.fit(X_tr, y_tr)
        yp   = clf.predict(X_te)
        yprob = clf.predict_proba(X_te)[:, 1]
        acc  = accuracy_score(y_te, yp)
        auc  = roc_auc_score(y_te, yprob)
        cv   = cross_val_score(clf, X_tr, y_tr, cv=5, scoring='accuracy')
        cm   = confusion_matrix(y_te, yp)
        rpt  = classification_report(y_te, yp, target_names=['Safe','Phishing'])

        print(f"{'─'*60}")
        print(f"  📊 {name}")
        print(f"{'─'*60}")
        print(f"  Accuracy  : {acc*100:.1f}%")
        print(f"  ROC-AUC   : {auc*100:.1f}%")
        print(f"  CV Score  : {cv.mean()*100:.1f}% ± {cv.std()*100:.1f}%")
        print(f"\n  Confusion Matrix (rows=actual, cols=predicted):")
        print(f"              Safe   Phishing")
        print(f"  Safe      [{cm[0,0]:>5}]  [{cm[0,1]:>5}]")
        print(f"  Phishing  [{cm[1,0]:>5}]  [{cm[1,1]:>5}]")
        print(f"\n{rpt}")

        if acc > best_acc:
            best_acc, best_name, best_clf = acc, name, clf

    print(f"{SEP}")
    print(f"  ✅ Best model: {best_name} ({best_acc*100:.1f}% accuracy)")
    print(SEP)
    return best_clf, tfidf, scaler

# ─────────────────────────────────────────────────────────────────────────────
# PREDICT
# ─────────────────────────────────────────────────────────────────────────────

def predict_single(text, clf, tfidf, scaler):
    uf = extract_url_features(text)
    tf = extract_text_features(text)
    m  = scaler.transform(pd.DataFrame([{**uf, **tf}]))
    v  = tfidf.transform([text])
    X  = hstack([v, csr_matrix(m)])
    pred = clf.predict(X)[0]
    prob = clf.predict_proba(X)[0]
    return ('Phishing' if pred else 'Safe', prob[1]*100, prob[0]*100)

def interactive_mode(clf, tfidf, scaler):
    SEP = "─" * 60
    print(f"\n🛡  PhishGuard — Interactive Prediction Mode")
    print(f"Type an email to analyze. Type 'quit' to exit.\n{SEP}")
    while True:
        try:
            text = input("\nEmail: ").strip()
            if text.lower() in ('quit','exit','q'): break
            if not text: continue
            label, phish_pct, safe_pct = predict_single(text, clf, tfidf, scaler)
            icon = '⚠️  PHISHING' if label == 'Phishing' else '✅ SAFE'
            print(f"  Result     : {icon}")
            print(f"  Phishing   : {phish_pct:.1f}%")
            print(f"  Safe       : {safe_pct:.1f}%")
        except (KeyboardInterrupt, EOFError):
            break
    print("\nGoodbye!")

if __name__ == '__main__':
    clf, tfidf, scaler = train()
    if '--predict' in sys.argv:
        interactive_mode(clf, tfidf, scaler)
